#include "copyright.h"
#include <stdio.h>
void PrintHello(){
    printf("hello world\n");
}